# DataResolve

**DataResolve** is an AI-powered forecasting tool for businesses. It uses Motha's Second Law of Probability to:
- Predict future sales
- Suggest when to hire extra staff
- Estimate Customer Lifetime Value (CLV)

## Features
- Upload sales data (CSV)
- 7-day sales forecast
- CLV estimator
- Peak day detector

## Run Locally

```bash
pip install -r requirements.txt
uvicorn dataresolve:app --reload
```

## Deployment
Perfect for Render or Railway deployment.

